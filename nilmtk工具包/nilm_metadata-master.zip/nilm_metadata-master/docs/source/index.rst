.. NILM Metadata documentation master file, created by
   sphinx-quickstart on Mon May 19 10:47:20 2014.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to NILM Metadata's documentation!
=========================================

Contents:

.. toctree::
   :maxdepth: 2

   tutorial
   dataset_metadata
   central_metadata


Indices and tables
==================

* :ref:`genindex`
* :ref:`search`

