********************
NILM Metadata Manual
********************

This has been renamed :doc:`tutorial`.
