#### Run all notebooks in manual using 1 python script : run_all_notebooks.py

1. You need to provide paths to REDD and other datasets in the notebooks.
2. Moreover, provide the path to the folder in nilmtk where you want to run all Jupyter Notebooks.
3. This python file outputs whether all notebooks ran successfully without error or not.


