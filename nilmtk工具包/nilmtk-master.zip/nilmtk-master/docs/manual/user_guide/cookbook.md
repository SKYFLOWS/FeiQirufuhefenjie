#### Visualisation

1. [How do I combine and display apparent and reactive power data on the same graph?](https://github.com/gjwo/nilm_gjw_data/blob/master/notebooks/graphing_two_metrics.ipynb)

#### Data set

1. [How do I find original building id in nilmtk](http://nipunbatra.github.io/2015/06/nilmtk-building-id/)