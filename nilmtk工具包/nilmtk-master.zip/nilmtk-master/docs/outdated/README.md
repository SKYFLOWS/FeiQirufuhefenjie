Please note that the notebooks here are only kept for historical purposes. See the [documentation](https://github.com/nilmtk/nilmtk/tree/master/docs/manual) instead.
