nilmtk.stats package
====================

Subpackages
-----------

.. toctree::

    nilmtk.stats.tests

Submodules
----------

nilmtk.stats.dropoutrate module
-------------------------------

.. automodule:: nilmtk.stats.dropoutrate
    :members:
    :undoc-members:
    :show-inheritance:

nilmtk.stats.dropoutrateresults module
--------------------------------------

.. automodule:: nilmtk.stats.dropoutrateresults
    :members:
    :undoc-members:
    :show-inheritance:

nilmtk.stats.goodsections module
--------------------------------

.. automodule:: nilmtk.stats.goodsections
    :members:
    :undoc-members:
    :show-inheritance:

nilmtk.stats.goodsectionsresults module
---------------------------------------

.. automodule:: nilmtk.stats.goodsectionsresults
    :members:
    :undoc-members:
    :show-inheritance:

nilmtk.stats.histogram module
-----------------------------

.. automodule:: nilmtk.stats.histogram
    :members:
    :undoc-members:
    :show-inheritance:

nilmtk.stats.totalenergy module
-------------------------------

.. automodule:: nilmtk.stats.totalenergy
    :members:
    :undoc-members:
    :show-inheritance:

nilmtk.stats.totalenergyresults module
--------------------------------------

.. automodule:: nilmtk.stats.totalenergyresults
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: nilmtk.stats
    :members:
    :undoc-members:
    :show-inheritance:
