nilmtk.feature_detectors package
================================

Submodules
----------

nilmtk.feature_detectors.cluster module
---------------------------------------

.. automodule:: nilmtk.feature_detectors.cluster
    :members:
    :undoc-members:
    :show-inheritance:

nilmtk.feature_detectors.steady_states module
---------------------------------------------

.. automodule:: nilmtk.feature_detectors.steady_states
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: nilmtk.feature_detectors
    :members:
    :undoc-members:
    :show-inheritance:
