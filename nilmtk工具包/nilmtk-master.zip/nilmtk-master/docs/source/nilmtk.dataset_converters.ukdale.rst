nilmtk.dataset_converters.ukdale package
========================================

Submodules
----------

nilmtk.dataset_converters.ukdale.convert_ukdale module
------------------------------------------------------

.. automodule:: nilmtk.dataset_converters.ukdale.convert_ukdale
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: nilmtk.dataset_converters.ukdale
    :members:
    :undoc-members:
    :show-inheritance:
