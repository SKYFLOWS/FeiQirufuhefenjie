nilmtk.stats.tests package
==========================

Submodules
----------

nilmtk.stats.tests.test_dropoutrate module
------------------------------------------

.. automodule:: nilmtk.stats.tests.test_dropoutrate
    :members:
    :undoc-members:
    :show-inheritance:

nilmtk.stats.tests.test_locategoodsections module
-------------------------------------------------

.. automodule:: nilmtk.stats.tests.test_locategoodsections
    :members:
    :undoc-members:
    :show-inheritance:

nilmtk.stats.tests.test_totalenergy module
------------------------------------------

.. automodule:: nilmtk.stats.tests.test_totalenergy
    :members:
    :undoc-members:
    :show-inheritance:

nilmtk.stats.tests.test_totalenergyresults module
-------------------------------------------------

.. automodule:: nilmtk.stats.tests.test_totalenergyresults
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: nilmtk.stats.tests
    :members:
    :undoc-members:
    :show-inheritance:
