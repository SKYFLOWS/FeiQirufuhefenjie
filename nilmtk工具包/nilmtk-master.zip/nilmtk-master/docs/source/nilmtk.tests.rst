nilmtk.tests package
====================

Submodules
----------

nilmtk.tests.generate_data module
---------------------------------

.. automodule:: nilmtk.tests.generate_data
    :members:
    :undoc-members:
    :show-inheritance:

nilmtk.tests.test_combinatorial_optimisation module
---------------------------------------------------

.. automodule:: nilmtk.tests.test_combinatorial_optimisation
    :members:
    :undoc-members:
    :show-inheritance:

nilmtk.tests.test_datastore module
----------------------------------

.. automodule:: nilmtk.tests.test_datastore
    :members:
    :undoc-members:
    :show-inheritance:

nilmtk.tests.test_datastore_converter module
--------------------------------------------

.. automodule:: nilmtk.tests.test_datastore_converter
    :members:
    :undoc-members:
    :show-inheritance:

nilmtk.tests.test_elecmeter module
----------------------------------

.. automodule:: nilmtk.tests.test_elecmeter
    :members:
    :undoc-members:
    :show-inheritance:

nilmtk.tests.test_measurement module
------------------------------------

.. automodule:: nilmtk.tests.test_measurement
    :members:
    :undoc-members:
    :show-inheritance:

nilmtk.tests.test_metergroup module
-----------------------------------

.. automodule:: nilmtk.tests.test_metergroup
    :members:
    :undoc-members:
    :show-inheritance:

nilmtk.tests.test_metrics module
--------------------------------

.. automodule:: nilmtk.tests.test_metrics
    :members:
    :undoc-members:
    :show-inheritance:

nilmtk.tests.test_node module
-----------------------------

.. automodule:: nilmtk.tests.test_node
    :members:
    :undoc-members:
    :show-inheritance:

nilmtk.tests.test_timeframe module
----------------------------------

.. automodule:: nilmtk.tests.test_timeframe
    :members:
    :undoc-members:
    :show-inheritance:

nilmtk.tests.testingtools module
--------------------------------

.. automodule:: nilmtk.tests.testingtools
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: nilmtk.tests
    :members:
    :undoc-members:
    :show-inheritance:
