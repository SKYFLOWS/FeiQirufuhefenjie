nilmtk.dataset_converters package
=================================

Subpackages
-----------

.. toctree::

    nilmtk.dataset_converters.ampds
    nilmtk.dataset_converters.combed
    nilmtk.dataset_converters.dataport
    nilmtk.dataset_converters.eco
    nilmtk.dataset_converters.greend
    nilmtk.dataset_converters.hes
    nilmtk.dataset_converters.iawe
    nilmtk.dataset_converters.redd
    nilmtk.dataset_converters.ukdale

Module contents
---------------

.. automodule:: nilmtk.dataset_converters
    :members:
    :undoc-members:
    :show-inheritance:
